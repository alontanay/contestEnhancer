const settings = {
    iconSize: 50,
    shineAnimationDuration: 0.2
};

document.head.innerHTML += `
<style>
#ce-icon-container {
    overflow: hidden;
    position: fixed;
    right: 10px;
    bottom: 10px;
    width: ${settings.iconSize}px;
    height: ${settings.iconSize}px;
    border-radius: 50%;
    border: 5px solid #2D508F;
    background-color: #4472C4;
}

#ce-icon {
    position: absolute;
    width: ${settings.iconSize}px;
    height: ${settings.iconSize}px;
}

#ce-icon-interactable {
    position: absolute;
    width: ${settings.iconSize}px;
    height: ${settings.iconSize}px;
}

@keyframes pass {
    0% {
        transform: translateX(${-settings.iconSize}px) rotate(45deg);
    }
    100% {
        transform: translateX(${settings.iconSize}px) rotate(45deg);
    }
}

#ce-icon-passer {
    background-color: rgba(255,255,255,0.5);
    width: 10px;
    height: 200px;
    margin: auto;
    position: absolute;
    top: -40px;
    transform: rotate(45deg);
    transform: translateX(${settings.iconSize}px);
}
.pass-animation {
    animation: pass ${settings.shineAnimationDuration}s linear 0s 1;
}


.ce-score {
    text-shadow:none;
    color:black;
    font-weight:bold;
    display:block;
    opacity:100%;
    background-opacity:100%;
}
.ce-side-score {
    padding:4px;
    width:100%;
    margin-top:3px;
    position:relative;
    left:-4px;
}
#ce-global-score {
    padding:20px;
    font-size:20px;
    top:50px;
    left:15px;
    position:fixed;
    border: 2px solid rgba(0,0,0,0.2);
    border-radius: 10px;
}
</style>
<style id="ce-vis-stylesheet">
.ce {
    display: none;
}
</style>
`;
document.body.innerHTML += `<div id="ce-icon-container">
<img id="ce-icon" src="${browser.runtime.getURL('icon.png')}">
<div id="ce-icon-passer" class="pass-animation"></div>
<div id="ce-icon-interactable" onmouseover="let csesEnhancerPasser = document.getElementById('ce-icon-passer'); let newClone = csesEnhancerPasser.cloneNode(true); event.target.parentElement.replaceChild(newClone,csesEnhancerPasser);"></div>
</div>  
`;

const VISIBILITY_STYLESHEET = document.getElementById('ce-vis-stylesheet');

let buttons = Array.from(document.getElementsByTagName('a')).filter((button)=>{return button.innerHTML=='Submissions';});
let total_max = 0;
let total_score = 0;

let data = {};

window.addEventListener('beforeunload',()=>{
    const publicScore = document.body.getElementsByClassName('score')[0].innerHTML.split('/');
    const max = parseInt(publicScore[1]);
    const score = parseInt(publicScore[0]);
    const problem = {}; problem[window.location.href.split('/')[5]] = {
        max: max,
        score: score
    };
    browser.storage.local.set(problem);
});

document.addEventListener('click',async(event)=> {
    if(event.target.id == 'ce-icon-interactable') {
        let DISABLED = !(await browser.storage.local.get('CE-DISABLED'))['CE-DISABLED'];
        await browser.storage.local.set({'CE-DISABLED':DISABLED});
        
        toggleVisibility(DISABLED);
    }
})

async function addScores() {
    data = await browser.storage.local.get();
    for(let button of buttons) {
        const name = button.href.split('/')[5];
        let max, score;
        if(data[name] == undefined) {
            const splitted = (await (await fetch(button.href)).text()).split('<span class=\"score\">')[1].split('</span>')[0].split('/');
            max = parseInt(splitted[1]);
            score = parseInt(splitted[0]);
            
            data[name] = {
                max: max,
                score: score
            };
        } else {
            max = data[name].max;
            score = data[name].score;
        }
        total_max += max;
        total_score += score;
        button.insertAdjacentHTML('afterend', `<span id="ce-score-${name}" class="ce ce-side-score ce-score" style="background-color:hsla(${score * 100 / max}, 100%, 50%, 0.4);">Score: ${score} / ${max}</span>`);
    }
    document.body.innerHTML += `<span id="ce-global-score" class="ce ce-score" style="background-color:hsla(${total_score * 100 / total_max}, 100%, 50%, 0.4);">Score:<br><br>${total_score} / ${total_max}</span>`;
    await browser.storage.local.set(data);
};

async function toggleVisibility(DISABLED) {
    VISIBILITY_STYLESHEET.disabled = DISABLED;
}

async function main() {
    if(window.location.href.endsWith('submissions')) {
        const publicScore = document.body.getElementsByClassName('score')[0].innerHTML.split('/');
        const max = parseInt(publicScore[1]);
        const score = parseInt(publicScore[0]);
        const problem = {}; problem[window.location.href.split('/')[5]] = {
            max: max,
            score: score
        };
        browser.storage.local.set(problem);
    }
    await toggleVisibility((await browser.storage.local.get('CE-DISABLED'))['CE-DISABLED']);
    await addScores();
}

main();